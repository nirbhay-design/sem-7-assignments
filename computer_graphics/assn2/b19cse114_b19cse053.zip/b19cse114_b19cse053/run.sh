#!/bin/bash

g++ $1 -lGL -lGLU -lglut

./a.out
